# BookKit — files & where they belong

This folder mirrors your repo layout. Drop each item at the matching path in
`Booking-App/`, then commit. Nothing here needs to move — the paths are already correct.

## What goes where

```
app/
  page.tsx                  ← REPLACES existing (Veya → BookKit rename applied)
  layout.tsx                ← REPLACES existing (browser title renamed)
  lib/supabase-browser.ts   ← REPLACES existing (error string renamed)
package.json                ← REPLACES existing (name → "bookkit")

supabase/
  migrations/
    0001_core_schema.sql    ← NEW — tables the app actually calls + no-overlap rule
    0002_rpcs.sql           ← NEW — create/update appointment functions the app calls
    0003_rls.sql            ← NEW — Row-Level Security (makes client-side calls safe)
    0004_storage.sql        ← NEW — client-photos bucket + policies
  test.mjs                  ← NEW — backend test suite (10 checks, all passing)

scripts/
  rename-to-bookkit.mjs     ← NEW — re-runnable Veya→BookKit rename pass

docs/                       ← reference material (not shipped code)
  BACKEND-FIX.md            ← why/what of the backend decision
  booking-engine-spec.md    ← the engine spec
  services-research.md      ← 10-trade durations/add-ons/deposit norms
  developer-prompt.md       ← original product/platform spec
  prototypes/*.html         ← clickable UI prototypes (design reference)
```

## Apply order
1. Copy the files to the matching paths above (replace where noted).
2. Apply the backend: `supabase db push` (or paste `supabase/migrations/*.sql` in order
   into the Supabase SQL editor). See `docs/BACKEND-FIX.md`.
3. Set env: `NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY`.
4. Run `node supabase/test.mjs` locally to confirm the backend (needs `@electric-sql/pglite`).

## Two things only you can finish
- **Rename the matching FILES for the two internal code refs** the rename touched:
  the `/api/veya` route dir/handler → `/api/bookkit`, and any `/public/veya-*.png`
  images → `/bookkit-*.png`. The text already points at the new names.
- **Retire the dead D1 setup** (the app runs on Supabase, D1 was unused): delete
  `db/` and `drizzle/`, drop `drizzle-orm`/`drizzle-kit` and the `db:generate`
  script from `package.json`, and remove the `d1` binding from `.openai/hosting.json`.
  Full rationale in `docs/BACKEND-FIX.md`.

## Note on the earlier `schema.ts`
An earlier step produced a consolidated Drizzle `schema.ts` for D1. That has been
**superseded** — since the app actually runs on Supabase, the Supabase migrations
here are the real backend, and D1 is the side to remove. It's intentionally not
included in this tree.

## What I can't do
I can't push to your GitHub or write into your project directly — no write access.
These files are organized so you (or a connected tool) can drop them in and commit.
```
```
